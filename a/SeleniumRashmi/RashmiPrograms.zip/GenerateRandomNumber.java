import java.lang.Math;  
public class GenerateRandomNumber {

	public static void main(String[] args) {
			int n=0;
		    while(n<5) {
			System.out.println(Math.random());
			n++;
		}
	}
	}
