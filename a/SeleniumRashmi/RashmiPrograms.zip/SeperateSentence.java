public class SeperateSentence {
            public static void main(String[] args) {
                String str = "work from home";
                String a[] = str.split(" "); 
          
                for (String s : a) 
                    System.out.println(s); 
            } 
        }
