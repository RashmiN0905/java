class  ReverseNum
{
	public static void main(String[] args) 
	{
		int num=10;
		for(int i=10; i>0; i--)
		{
		System.out.println(i);
		}
	}
}
