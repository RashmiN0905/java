class  LastDigit
{
	public static void main(String[] args) 
	{
		int num = 765;
		int lastDigit=num%10;
		System.out.println(lastDigit+" is the last digit of number "+num);
	}
}
