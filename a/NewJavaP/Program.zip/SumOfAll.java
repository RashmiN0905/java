class  SumOfAll
{
	public static void main(String[] args) 
	{
		int sum=0;
		int num=1;
		do
		{
		sum=sum+num;
		num++;
		}
		while(num<=20);
		System.out.println(sum);
	}
}
